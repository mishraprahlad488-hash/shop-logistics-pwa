Shop Logistics PWA
React-based offline shop management app.
Demo login: owner@example.com / 123456